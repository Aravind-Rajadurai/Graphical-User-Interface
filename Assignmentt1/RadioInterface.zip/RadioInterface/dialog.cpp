#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    player = new QMediaPlayer(this);

    connect(player, &QMediaPlayer::positionChanged, this, &Dialog::on_positionChanged);
    connect(player, &QMediaPlayer::durationChanged, this, &Dialog::on_durationChanged);
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_progressSlider_sliderMoved(int position)
{
    player ->setPosition(position);
}

void Dialog::on_dialVolume_sliderMoved(int position)
{
    player->setVolume(position);
}

void Dialog::on_verticalSlider_2_sliderMoved(int position)
{
    player ->setPosition(position);
}

void Dialog::on_verticalSlider_sliderMoved(int position)
{
    player ->setPosition(position);
}

void Dialog::on_skipStations_sliderMoved(int position)
{
    player ->setPosition(position);
}


void Dialog::on_amButton_clicked()
{
    player -> setMedia(QUrl::fromLocalFile(""));
    player->play();
    qDebug()<<player->errorString();
}

void Dialog::on_fmButton_clicked()
{
    player -> setMedia(QUrl::fromLocalFile(""));
    player->play();
    qDebug()<<player->errorString();
}

void Dialog::on_positionChanged(qint64 position)
{
    ui->progressSlider->setValue(position);
}

void Dialog::on_durationChanged(qint64 position)
{
    ui->progressSlider->setMaximum(position);
}
