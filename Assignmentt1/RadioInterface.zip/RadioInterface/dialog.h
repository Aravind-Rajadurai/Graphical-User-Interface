#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QMediaPlayer>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class Dialog; }
QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT

public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_progressSlider_sliderMoved(int position);

    void on_dialVolume_sliderMoved(int position);

    void on_verticalSlider_2_sliderMoved(int position);

    void on_verticalSlider_sliderMoved(int position);

    void on_skipStations_sliderMoved(int position);

    void on_amButton_clicked();

    void on_fmButton_clicked();

    void on_positionChanged(qint64 position);

    void on_durationChanged(qint64 position);

private:
    Ui::Dialog *ui;
    QMediaPlayer* player;
};
#endif // DIALOG_H
